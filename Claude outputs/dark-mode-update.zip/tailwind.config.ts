import type{Config}from"tailwindcss";
const v=(n:string)=>`rgb(var(--${n}) / <alpha-value>)`;
export default{content:["./src/**/*.{ts,tsx}"],theme:{extend:{colors:{cream:{DEFAULT:v("cream"),50:v("cream-50"),100:v("cream"),200:v("cream-200"),300:v("cream-300")},ink:{DEFAULT:v("ink"),800:v("ink-800"),600:v("ink-600"),400:v("ink-400")}},fontFamily:{sans:["var(--f-sans)","system-ui","sans-serif"],serif:["var(--f-serif)","Georgia","serif"]},maxWidth:{site:"1240px"}}},plugins:[]}satisfies Config;
