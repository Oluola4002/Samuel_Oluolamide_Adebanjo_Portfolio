"use client";
import{Component,lazy,Suspense,useEffect,useRef,useState,type ReactNode}from"react";
import Portraits from"./Portraits";
import{BG,type Theme}from"./ThemeToggle";
import type{Application}from"@splinetool/runtime";

const Spline=lazy(()=>import("@splinetool/react-spline"));
/* If the 3D scene fails (slow or blocked network), show the photo slideshow instead of crashing the page. */
class Safe extends Component<{children:ReactNode},{err:boolean}>{state={err:false};static getDerivedStateFromError(){return{err:true}}componentDidCatch(){}render(){return this.state.err?<div className="mx-auto max-w-[460px] pt-10"><Portraits/></div>:this.props.children}}
function Loader(){return <div className="absolute inset-0 grid place-items-center"><span className="h-8 w-8 animate-spin rounded-full border-2 border-ink/15 border-t-ink"/></div>}

/* Interactive 3D robot. Only loads on large screens, so phones never download the 3D engine. */
export default function SplineRobot(){
 const[show,setShow]=useState(false),app=useRef<Application|null>(null);
 const paint=()=>{const t=(document.documentElement.dataset.theme as Theme)||"light";try{app.current?.setBackgroundColor(BG[t])}catch{}};
 useEffect(()=>{addEventListener("themechange",paint);return()=>removeEventListener("themechange",paint)},[]);
 useEffect(()=>{const q=matchMedia("(min-width:1024px)");const f=()=>setShow(q.matches);f();q.addEventListener("change",f);return()=>q.removeEventListener("change",f)},[]);
 if(!show)return null;
 return(<div className="relative h-[560px] w-full xl:h-[640px]">
  <Safe><Suspense fallback={<Loader/>}><Spline scene="https://prod.spline.design/kZDDjO5HuC9GJUM2/scene.splinecode" onLoad={(a:Application)=>{app.current=a;paint()}}/></Suspense></Safe>
 </div>);
}
